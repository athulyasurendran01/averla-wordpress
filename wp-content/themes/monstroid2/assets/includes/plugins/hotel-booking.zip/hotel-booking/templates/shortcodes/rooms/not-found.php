<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="mphb-not-found">
	<?php _e( 'No accommodations matching criteria.', 'motopress-hotel-booking' ); ?>
</p>