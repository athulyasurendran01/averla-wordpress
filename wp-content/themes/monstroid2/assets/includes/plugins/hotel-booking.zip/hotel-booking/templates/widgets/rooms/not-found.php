<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

_e( 'Nothing found.', 'motopress-hotel-booking' );